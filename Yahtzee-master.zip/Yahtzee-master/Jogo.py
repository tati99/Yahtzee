'''
from XXXX import *

def reiniciar_Jogo():

def finalizar_Jogo():

def sair_Do_Jogo():

def calcularGanhador()
'''
